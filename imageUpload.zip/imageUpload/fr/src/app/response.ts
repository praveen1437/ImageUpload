import { Image } from "./image";

export class Response {
     images: Image[];
}
