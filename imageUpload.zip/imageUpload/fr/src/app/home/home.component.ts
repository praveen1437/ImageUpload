import { Component, OnInit } from '@angular/core';
import { ImageService } from '../Services/image.service';
import { Image } from '../image';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  public images  = [];

  constructor(private imageService: ImageService, private router: Router) { }

  ngOnInit() {
    var ele = document.getElementById("homeImage");
    console.log("#### ele : " + ele);
    this.imageService.fetchAllImages().subscribe(data => {
      console.log("## data size" + data.images.length)
      data.images.map(image =>      
        this.images.push(image))
        console.log("## this size" + this.images.length)
      }); 
     
  }

  loadImage(img) {
    //document.getElementById("homeImage").style.display = "none";
    this.router.navigate(['/show',img.id])
    //document.getElementById("ImageComponent").style.display = "block";
    
  }

  addNewImage() {
    document.getElementById("homeImage").style.display = "none";
    this.router.navigate(['/new'])
  }

}
