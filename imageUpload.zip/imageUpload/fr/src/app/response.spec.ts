import { Response } from './response';

describe('Response', () => {
  it('should create an instance', () => {
    expect(new Response()).toBeTruthy();
  });
});
