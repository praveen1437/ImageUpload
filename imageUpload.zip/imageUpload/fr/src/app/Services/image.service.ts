import { HttpClient} from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Image } from '../image';
import { ImageResponse } from '../image-response';
import { Response } from '../response';

@Injectable({
  providedIn: 'root'
})
export class ImageService {

  private AllImagesUrl = "http://localhost:8181/images/";


  constructor(private http: HttpClient) { }

  public fetchAllImages() : Observable<Response> {
    return this.http.get<Response>(this.AllImagesUrl);
  }

  public loadImage(id:number) : Observable<ImageResponse> {
    console.log("#### in fetch single : " + id);
    console.log("#### in fetch single : " + this.AllImagesUrl +id);
    return this.http.get<ImageResponse>(this.AllImagesUrl+id);

  }
}
