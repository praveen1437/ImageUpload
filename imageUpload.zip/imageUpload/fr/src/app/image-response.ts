export class ImageResponse {
}
