import { ImageResponse } from './image-response';

describe('ImageResponse', () => {
  it('should create an instance', () => {
    expect(new ImageResponse()).toBeTruthy();
  });
});
