import { Image } from './image';

describe('Image', () => {
  it('should create an instance', () => {
    expect(new Image()).toBeTruthy();
  });
});
