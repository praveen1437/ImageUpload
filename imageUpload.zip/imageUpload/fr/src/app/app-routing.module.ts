import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { ImageComponent } from './image/image.component';
import { NewImageComponent } from './new-image/new-image.component';


const routes: Routes = [
  {path : "show/:id", component : ImageComponent},
  {path : "new", component : NewImageComponent},
  {path : "home", redirectTo : "", pathMatch : 'full'},
  {path : "", component : HomeComponent}

  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const routingComponents = [ImageComponent,HomeComponent,NewImageComponent]
