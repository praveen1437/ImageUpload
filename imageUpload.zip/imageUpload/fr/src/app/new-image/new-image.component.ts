import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-new-image',
  templateUrl: './new-image.component.html',
  styleUrls: ['./new-image.component.css']
})
export class NewImageComponent implements OnInit {

  constructor(private routes: Router) { }

  ngOnInit() {
  }

  goBack() {   
    // document.getElementById("homeImage").style.display = "block";
     this.routes.navigateByUrl("")
     //document.getElementById("ImageComponent").style.display = "none";
   }

}
