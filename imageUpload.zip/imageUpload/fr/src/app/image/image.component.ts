
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, convertToParamMap, ParamMap, Router } from '@angular/router';
import { Image } from '../image';
import { ImageService } from '../Services/image.service';


@Component({
  selector: 'app-image',
  templateUrl: './image.component.html',
  styleUrls: ['./image.component.css']
})
export class ImageComponent implements OnInit {
  private image : Image;
  private id;

  constructor(private imageService: ImageService, private route: ActivatedRoute, private routes: Router) { }

  ngOnInit() {
    document.getElementById("homeImage").style.display = "none";
    //document.getElementById("ImageComponent").style.display = "block";
     console.log("##### in image init");
      this.route.paramMap.subscribe((params: ParamMap) =>{
      this.id=params.get('id')
      console.log("####id  : " + this.id );  
      this.imageService.loadImage(this.id).subscribe(data =>{
      this.setImageData(data);
      })
    })
  }

  setImageData(data) {
    console.log("#### setimagedata : " + data);
    console.log("#### setimagedata : " + Object.values(data));
    this.image = data.image;
  }

  goBack() {   
   // document.getElementById("homeImage").style.display = "block";
    this.routes.navigateByUrl("")
    //document.getElementById("ImageComponent").style.display = "none";
  }
}
