export class Image {
    id:number;
    imageName: string;
    imageURL: string;
    imageDetails:string;

    
}
