package com.techm.imageUpload.Controllers;

import com.techm.imageUpload.Entities.Image;
import com.techm.imageUpload.Response.ImageDetailsResponse;
import com.techm.imageUpload.Response.ImageResponse;
import com.techm.imageUpload.Services.ImageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * Class performs
 */
@RestController
@CrossOrigin
@RequestMapping("/images")
public class ImageController {

    @Autowired
    ImageService imageService;

    /**
     * This methods returns all the available images
     *
     * @return ImageDetailsResponse
     */
    @GetMapping("/")
    public ImageDetailsResponse getAllImages() {
        System.out.println("in fetch all controller");
        return imageService.getAllImages();
    }

    /**
     * This method fetches image based on given id
     *
     * @param id
     * @return ImageResponse
     */
    @GetMapping("/{id}")
    public ImageResponse fetchImage(@PathVariable String id) {
        System.out.println("in fetching single image");
        return imageService.fetchImage(id);
    }

    /**
     * This method stores new Image into DB
     *
     * @param image
     * @return
     */
    @PostMapping("/")
    public String saveImage(@RequestBody Image image) {
        String response = "SUCCESS";
        try {
            imageService.saveImage(image);
        } catch (Exception e) {
            response = "ERROR";
        }
        return response;
    }
}
