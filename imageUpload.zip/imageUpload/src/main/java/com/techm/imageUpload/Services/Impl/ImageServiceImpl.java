package com.techm.imageUpload.Services.Impl;

import com.techm.imageUpload.Entities.Image;
import com.techm.imageUpload.Repositories.ImageRepository;
import com.techm.imageUpload.Response.ImageDetailsResponse;
import com.techm.imageUpload.Response.ImageResponse;
import com.techm.imageUpload.Services.ImageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ImageServiceImpl implements ImageService {

    @Autowired
    private ImageRepository imageRepository;

    /**
     * Fetches all Images
     *
     * @return ImageDetailsResponse, which Consists List of Images
     */
    @Override
    public ImageDetailsResponse getAllImages() {
        ImageDetailsResponse imageDetailsResponse = new ImageDetailsResponse();
        imageDetailsResponse.setImages((List<Image>) imageRepository.findAll());

        System.out.println("size of images : " + imageDetailsResponse.getImages().size());
        return imageDetailsResponse;
    }

    /**
     * Fetches Images based on provided Id
     *
     * @param id
     * @return ImageResponse, which contains details of a particular Image
     */
    @Override
    public ImageResponse fetchImage(String id) {
        ImageResponse imageResponse = new ImageResponse();
        imageResponse.setImage(imageRepository.findById(Long.parseLong(id)).get());
        return imageResponse;
    }

    /**
     * Saves new Image into DB
     *
     * @param image
     */
    @Override
    public void saveImage(Image image) {
        imageRepository.save(image);
    }
}
