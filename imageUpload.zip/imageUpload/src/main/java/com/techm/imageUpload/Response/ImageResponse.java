package com.techm.imageUpload.Response;

import com.techm.imageUpload.Entities.Image;

public class ImageResponse {
    private Image image;

    public Image getImage() {
        return image;
    }

    public void setImage(Image image) {
        this.image = image;
    }
}
