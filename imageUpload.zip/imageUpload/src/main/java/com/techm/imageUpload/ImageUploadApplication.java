package com.techm.imageUpload;

import com.techm.imageUpload.Entities.Image;
import com.techm.imageUpload.Repositories.ImageRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import sun.tools.jar.CommandLine;

@SpringBootApplication
public class ImageUploadApplication implements CommandLineRunner {

	@Autowired
	ImageRepository imageRepository;

	public static void main(String[] args) {
		SpringApplication.run(ImageUploadApplication.class, args);

	}

	@Override
	public void run(String... args) throws Exception {
		Image image = new Image();
		image.setImageDetails("test 1");
		image.setImageName("Sky");
		image.setImageURL("https://thumbs.dreamstime.com/b/picturesque-autumn-scenery-santa-maddalena-village-church-road-colorful-trees-meadows-foreground-mountain-peaks-159426189.jpg");
		for(int i = 0; i < 3; i++) {
			image.setId((long) (i+1));
			System.out.println("####  url" + image.getImageURL() );
			imageRepository.save(image);
		}
	}
}
