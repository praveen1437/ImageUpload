package com.techm.imageUpload.Response;

import com.techm.imageUpload.Entities.Image;

import java.util.List;

public class ImageDetailsResponse {
    private List<Image> images;

    public List<Image> getImages() {
        return images;
    }

    public void setImages(List<Image> images) {
        this.images = images;
    }
}
