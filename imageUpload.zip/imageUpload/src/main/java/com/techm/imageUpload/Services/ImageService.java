package com.techm.imageUpload.Services;

import com.techm.imageUpload.Entities.Image;
import com.techm.imageUpload.Response.ImageDetailsResponse;
import com.techm.imageUpload.Response.ImageResponse;
import org.springframework.stereotype.Service;


public interface ImageService {
    /**
     * Fetches all Images
     *
     * @return ImageDetailsResponse, which Consists List of Images
     */
    ImageDetailsResponse getAllImages();

    /**
     * Fetches Images based on provided Id
     *
     * @param id
     * @return ImageResponse, which contains details of a particular Image
     */
    ImageResponse fetchImage(String id);

    /**
     * Saves new Image into DB
     *
     * @param image
     */
    void saveImage(Image image);
}
